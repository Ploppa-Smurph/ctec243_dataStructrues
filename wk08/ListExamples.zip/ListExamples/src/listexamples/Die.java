/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listexamples;

import java.util.Iterator;
import java.util.Random;

/**
 *
 * @author sturner
 */
public class Die implements Iterable<Integer>{
    
    int sides;
    Random generator;
    int numberOfRolls;
    
    public Die(int sides){
        this.sides = sides;
        generator = new Random();
        numberOfRolls = 1;
    }
    public Die(){
        this.sides = 20;
        generator = new Random();
        numberOfRolls = 1;
    }
    
    public void setRolls(int number){
        this.numberOfRolls = number;
    }
    
    private int roll(){
        return generator.nextInt(sides) + 1;
    }

    @Override
    public Iterator<Integer> iterator() {
        return new DieIterator(numberOfRolls);
    }
    
    private class DieIterator implements Iterator<Integer>{

            
        int internalRolls;
        
        public DieIterator(int number){
            internalRolls = number;
        }

        @Override
        public boolean hasNext() {
            return (internalRolls > 0);
        }

        @Override
        public Integer next() {
            internalRolls--;
            return roll();
        }
        
        
    }
   
    
}
