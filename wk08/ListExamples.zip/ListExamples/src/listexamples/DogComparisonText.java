/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listexamples;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author sturner
 */
public class DogComparisonText {
    
    
    public static void main(String[] args) {
        ArrayList<Dog> dogList = new ArrayList<>();
        
        dogList.add(new Dog("Fred", 7, 1));
        dogList.add(new Dog("Wilbur", 10, 3));
        dogList.add(new Dog("Archie", 10, 3));
        dogList.add(new Dog("Francis", 3, 10));
        dogList.add(new Dog("Sir Chompsalot", 8, 10));
        
        //Collections.sort(dogList, new DogComparer());
        dogList.sort(null);
        
        for(Dog d : dogList){
            System.out.println(d);
        }
    }
}
