/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listexamples;

/**
 *
 * @author sturner
 */
public class TurnerLinkedListTester {
    
    public static void main(String[] args) {
        TurnerLinkedList<Integer> tll = new TurnerLinkedList<>();
        
        tll.add(5);
        tll.add(6);
        tll.add(2);
        
        System.out.println(tll.printList());
        tll.insert(1, 0);
        tll.insert(9, 0);
         System.out.println(tll.printList());
         
    }
    
}
