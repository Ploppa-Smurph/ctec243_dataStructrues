/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listexamples;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author sturner
 */
public class ListExamples {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Integer> myIntList = new ArrayList<>();
        
        myIntList.add(7);
        myIntList.add(14);
        myIntList.add(23);
        myIntList.add(30);
        
        
        Iterator<Integer> myIntIterator = myIntList.iterator();
        while(myIntIterator.hasNext()){
            int i = myIntIterator.next();
            System.out.println(i);
            if(i == 7) myIntIterator.remove();
        }
        System.out.println("-----Modified List------");
        
        
        for(Integer i : myIntList){
            System.out.println(i);
        }
        
    }
    
}
