/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listexamples;

/**
 *
 * @author sturner
 */
public class Dog implements Comparable<Dog>{
    //Field
    public String name;
    public int CutenessLevel;
    public int age;
    
    //constructor
    public Dog(String name, int cute, int age){
        this.name = name;
        this.CutenessLevel = cute;
        this.age = age;
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        else if(o == null || o.getClass() != this.getClass()) return false;
        else {
            Dog other = (Dog) o;
            return (this.name == other.name 
                    && this.CutenessLevel == other.CutenessLevel
                    && this.age == other.age);
        }
    }

    @Override
    public int compareTo(Dog otherDog) {
        if(this.CutenessLevel != otherDog.CutenessLevel){
            return this.CutenessLevel - otherDog.CutenessLevel;
        } else if (this.age != otherDog.age){
            return otherDog.age - this.age;
        } else {
            return this.name.compareTo(otherDog.name);
        }

    }
    
    public String toString(){
        return this.name + " Cuteness: " + this.CutenessLevel + " Age: " + this.age;
    }
}
