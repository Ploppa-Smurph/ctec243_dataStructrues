/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listexamples;

/**
 *
 * @author sturner
 */
public class TurnerLinkedList<T> {
    
    private class Node{
        public T data;
        public Node next;
        public Node(T data){
            this.data = data;
        }
    }
    
    private Node front;
    private Node back;
    private int count;
    
    public TurnerLinkedList(){
        front = null;
        back = null;
        count = 0;
    }
    
    //Add to the back of the list
    public void add(T data){
        if(back == null){
            Node temp = new Node(data);
            back = temp;
            front = temp;
        } else {
            back.next = new Node(data);
            back = back.next;
        }
        count++;
    }
    
    //print out the list
    public String printList(){
        String listString = "";
        Node current = front;
        while(current != null){
            listString += current.data.toString();
            current = current.next;
        }
        return listString;
    }
    
    //Add to an index inside the list
    public void insert(T data, int index){
        if(index >= 0 && index <= size()){
            Node current = front;
            Node previous = null;
            
            for(int i = 0; i < index; i++){
                previous = current;
                current = current.next;
            }
            if(previous == null){
                Node temp = new Node(data);
                temp.next = current;
                front = temp;
            } else {
                
                Node temp = new Node(data);
                previous.next = temp;
                temp.next = current;
                if(current == null){
                    back = temp;
                }
            }
            
            
        } else {
            throw new IndexOutOfBoundsException();
        }
    }
    
    //Remove from an index inside the list
    
    //get the size of the list
    public int size(){
//        int count = 0;
//        Node current = front;
//        while(current != null){
//            count++;
//            current = current.next;
//        }
        return count;
    }
    
}
