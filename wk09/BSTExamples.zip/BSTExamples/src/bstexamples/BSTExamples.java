/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bstexamples;

/**
 *
 * @author sturner
 */
public class BSTExamples {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        TurnerBST<Integer> test = new TurnerBST<>();
        
        test.recAdd(3);
        test.recAdd(4);
        test.recAdd(1);
        test.recAdd(2);
        test.recAdd(5);
        test.recAdd(1);
        test.recAdd(2);
        
        System.out.println(test.getInOrderString());
        
        test.remove(3);
        test.remove(2);
        test.remove(5);
        
        System.out.println(test.getInOrderString());
    }
    
}
