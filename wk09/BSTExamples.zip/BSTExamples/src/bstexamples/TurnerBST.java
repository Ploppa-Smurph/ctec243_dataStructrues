package bstexamples;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sturner
 */
public class TurnerBST<T extends Comparable<T>> {
    
    private class Node{
        T data;
        Node left;
        Node right;
        
        public Node(T data){
            this.data = data;
        }
    }
    
    Node root;
    
    public TurnerBST(){
        root = null;
    }
    
    public TurnerBST(T data){
        root = new Node(data);
    }
    
    //should be able to add to it
    public void add(T data){
        if(root == null) root = new Node(data);
        else {
            Node current = root;
            Node parent = null;
            //Walk down paths to find empty spot where data belongs
            while(current != null){
                parent = current;
                if(data.compareTo(current.data) < 0){
                    current = current.left;
                } else {
                    current = current.right;
                }
            }
        //We found the spot, we've got the parent, we just have to add it to the right place
        if(data.compareTo(parent.data) < 0) parent.left = new Node(data);
        else parent.right = new Node(data);
        }
    }
    
    //starter method for recursive add
    public void recAdd(T data){
        root = recAdd(data, root);
    }
    
    //this does the recursive work
    private Node recAdd(T data, Node c){
        //if the tree is empty, add to the root
        if(c == null) return new Node(data);
        //if the tree is not empty:
        //if data is less than root data, add to tree on left
        if(data.compareTo(c.data) < 0) c.left = recAdd(data, c.left);
        else c.right = recAdd(data, c.right);
        
        return c;   
    }
    
    //remove stuff
    public void remove(T data){
        root = remove(data, root);
    }
    
    //The recursive workhorse for remove
    private Node remove(T data, Node c){
        if(c == null) return null; //you didn't find it.  Might be better practice to throw an error here, we'll just return null
        
        int comparison = data.compareTo(c.data); //get the comparison info
        if(comparison == 0){ //if we found it
            if(c.left == null && c.right == null){ //if it has no children, just replace it with null
                return null;
            }
            else if (c.left == null){ //if it doesn't have a left at this point, then it must have a right
                c = c.right;
            } else if (c.right == null){//if it doesn't have a right at this point, then it must have a left
                c = c.left;
            } else {
                //it has two children
                //find the smallest child on the right (since the right can contain duplicates)
                Node replacement = getSmallestRightChild(c.right);
                //set the data in the current with the data from the largest child
                c.data = replacement.data;
                //remove the largest child
                c.right = remove(replacement.data, c.right);
            }
        } else if (comparison < 0){
            c.left = remove(data, c.left);
        } else {
            c.right = remove(data, c.right);
        }
        
        //return the node so that we return the tree we recursively modified
        return c;
    }
    
    private Node getLargestLeftChild(Node c){
        Node current = c;
        while (current.right != null){
            current = current.right;
        }
        return current;
    }
    
    private Node getSmallestRightChild(Node c){
        Node current = c;
        while (current.left != null){
            current = current.left;
        }
        return current;
    }
    
    //should be able to print out elements
    public String getInOrderString(){
        return getInOrderString(root);
    }
    
    public String getInOrderString(Node c){
        if(c == null) return "";
        
        String s = "";
        s += getInOrderString(c.left);
        s += c.data.toString();
        s += getInOrderString(c.right);
        
        return s;
    }
    //should be able to remove from it
    
}
