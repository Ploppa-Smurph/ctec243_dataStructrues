/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package turnersorts;

/**
 *
 * @author sturner
 */
public class TurnerSorts {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] array = {3,2,5,3,1,6,4,7,1};
        
        //sort here
        mergeSort(array, 0, array.length -1);
        //print out the list
        for(int x : array){
            System.out.println(x);
        }
    }
    
    public static void selectionSort(int[] array){
        
        for(int outerCount = 0; outerCount < array.length - 1; outerCount++){
            //assume smallest is first item
            int smallestIndex = outerCount;
            //loop through list
            for(int innerCount = outerCount + 1; innerCount < array.length; innerCount++){
                //if index is smaller than smallest, update smallest to it
                if(array[innerCount] < array[smallestIndex]){
                    smallestIndex = innerCount;
                }
            }
            //after we've looped through the whole thing,
            //we've found the smallest
            //swap it with the beginning
            swap(array, outerCount, smallestIndex);
        }
        
    }
    
    public static void swap(int[] array, int position1, int position2){
        int temp = array[position1];
        array[position1] = array[position2];
        array[position2] = temp;
    }
    
    public static void insertionSort(int[] array){
        for(int outerIndex = 1; outerIndex < array.length; outerIndex++){
                    //sorted list: just index 0
            int addedIndex = outerIndex;
            while(addedIndex >= 1 && array[addedIndex] < array[addedIndex - 1]){
                swap(array, addedIndex, addedIndex -1);
                addedIndex--;
            }
        }
    }
    
    public static void bubbleSort(int[] array){
        for(int outerIndex = 0; outerIndex < array.length; outerIndex++){
                    //look from end to beginning
            //if value is smaller than what's before it, swap it
            for(int index = array.length -1; index > outerIndex; index--){
                if(array[index] < array[index -1]){
                    swap(array, index, index-1);
                }
            }
        }

    }
    
    public static void mergeSort(int[] array){
        mergeSort(array, 0, array.length - 1);
    }
    
    private static void mergeSort(int[] array, int start, int end){
        if(start >= end){
            return;
        }
        //split the array in half
        int middleIndex = (start + end) / 2;
        int leftFirst = start;
        int leftLast = middleIndex;
        int rightFirst = middleIndex + 1;
        int rightLast = end;
        //sort the left side
        mergeSort(array, leftFirst, leftLast);
        //sort the right side
        mergeSort(array, rightFirst, rightLast);
        //merge the two arrays
        int[] tempArray = new int[array.length];
        int tempCount = start;
        while(leftFirst <= leftLast && rightFirst <= rightLast){
            if(array[leftFirst] < array[rightFirst]){
                tempArray[tempCount] = array[leftFirst];
                leftFirst++;
            } else {
                tempArray[tempCount] = array[rightFirst];
                rightFirst++;
            }
            tempCount++;
        }
        
        while(leftFirst <= leftLast){
            tempArray[tempCount] = array[leftFirst];
            leftFirst++;
            tempCount++;
        }
        
        while(rightFirst <= rightLast){
            tempArray[tempCount] = array[rightFirst];
            rightFirst++;
            tempCount++;
        }
        
        for(int i = start; i <= end; i++){
            array[i] = tempArray[i];
        }
    }
    
    static void TurnerQuickSort(int[] array, int firstIndex, int lastIndex){
      //get a starting value
      if(firstIndex < lastIndex){
            int pivotIndex = firstIndex;
            int pivotValue = array[pivotIndex];

            //place everything less than that value to the "left" of it
            //we're creating a separate list, so mark it with a variable to store the index at the "end" of that list
            int endOfLeftList = firstIndex;
            //then loop through all values, swapping them to the "left list" if they're less than the middle value
            for(int i = firstIndex + 1; i <= lastIndex; i++){
                if(array[i] < pivotValue){
                    //add to the end of the left list
                    endOfLeftList++;
                    swap(array, i, endOfLeftList);
                }
            }

            //middle value is still at the start, so swap it with the last item in the "left list" to keep it sorted
            swap(array, firstIndex, endOfLeftList);

            //middle value is now sorted, but everything else is still in the wrong place
            //now sort the leftList and the RightList using Quick Sort
            TurnerQuickSort(array, firstIndex, endOfLeftList-1);
            TurnerQuickSort(array, endOfLeftList+1, lastIndex);
      }
  }
    
}
