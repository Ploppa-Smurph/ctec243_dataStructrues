/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collectionexamples2;

/**
 *
 * @author Steven Turner
 */
public interface Collection<T> {
    boolean add(T element);
    T get(T target);
    boolean contains(T target);
    boolean remove(T target);
    
    boolean isFull();
    boolean isEmpty();
    int size();
}
