/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collectionexamples2;

/**
 *
 * @author Steven Turner
 */
public class Puppy implements Comparable<Puppy>{
    //fields
    private int age;
    private int cuteness;
    private String name;
    
    public Puppy(int age, int cuteness, String name){
        this.age = age;
        this.cuteness = cuteness;
        this.name = name;
    }
    
    public String toString(){
        return name + " is " + age + " years old and is level " + cuteness + " cute";
    }

    @Override
    public int compareTo(Puppy other) {
        return this.cuteness - other.cuteness;
    }

    
    
}
