/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collectionexamples2;

import java.util.ArrayList;

/**
 *
 * @author Steven Turner
 */
public class CollectionExamples2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Puppy> puppyList = new ArrayList<>();
        
        puppyList.add(new Puppy(1, 7, "Lord Framingham"));
        puppyList.add(new Puppy(3, 1, "wilford"));
        puppyList.add(new Puppy(2, 4, "Barry"));
        
        
        puppyList.sort(null);
        
        for(Puppy p : puppyList){
            System.out.println(p);
        }
    }
    
}
