/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collectionexamples2;

/**
 *
 * @author Steven Turner
 */
public class TurnerCollection<T> implements Collection<T> {
    //fields
    T[] array = (T[]) new Object[10];
    int count = 0; //represents next empty spot in the array
    
    //constructor
    
    
    //methods

    @Override
    public boolean add(T element) {
        if(!isFull()){
            array[count] = element;
            count++;
            return true;
        } else return false;
    }

    @Override
    public T get(T target) {
        int position = find(target);
        if(position >= 0) return array[position];
        else return null;
    }

    @Override
    public boolean contains(T target) {
        return (find(target) >= 0);
    }

    @Override
    public boolean remove(T target) {
        int position = find(target);
        //see if the target is in there
        if(position < 0) return false;
                
        //if it is, swap the found position with the last position, then subtract 1 from count
        count--;
        array[position] = array[count];
        array[count] = null;
        
        return true;
    }

    @Override
    public boolean isFull() {
        return count == array.length;
    }

    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public int size() {
        return count;
    }
    
    private int find(T element){ //return the position, return -1 if it's not found
        for(int i = 0; i < count; i++){
            if(array[i].equals(element)) return i;
        }
        
        return -1;
    }
    
}
